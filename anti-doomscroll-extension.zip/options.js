// Options page JavaScript for Anti-Doomscroll Chrome Extension

// Default configuration
const DEFAULT_SITES = {
  'instagram.com': { enabled: true, dailyLimit: 60, weeklyLimit: 300, icon: '📷' },
  'tiktok.com': { enabled: true, dailyLimit: 30, weeklyLimit: 150, icon: '🎵' },
  'twitter.com': { enabled: true, dailyLimit: 45, weeklyLimit: 200, icon: '🐦' },
  'x.com': { enabled: true, dailyLimit: 45, weeklyLimit: 200, icon: '🐦' },
  'youtube.com': { enabled: true, dailyLimit: 90, weeklyLimit: 400, icon: '📺' },
  'facebook.com': { enabled: true, dailyLimit: 30, weeklyLimit: 150, icon: '👥' },
  'reddit.com': { enabled: true, dailyLimit: 60, weeklyLimit: 300, icon: '🔴' }
};

// DOM elements
let sitesList, appUrlInput, saveBtn, resetBtn, exportBtn, statsContainer;

// Initialize the options page
document.addEventListener('DOMContentLoaded', async () => {
  sitesList = document.getElementById('sitesList');
  appUrlInput = document.getElementById('appUrl');
  saveBtn = document.getElementById('saveSettings');
  resetBtn = document.getElementById('resetSettings');
  exportBtn = document.getElementById('exportSettings');
  statsContainer = document.getElementById('statsContainer');

  // Load current settings
  await loadSettings();
  
  // Set up event listeners
  setupEventListeners();
  
  // Load usage statistics
  await loadUsageStats();
});

// Load current settings from storage
async function loadSettings() {
  try {
    const result = await chrome.storage.sync.get(['blockedSites', 'appUrl']);
    const blockedSites = result.blockedSites || DEFAULT_SITES;
    const appUrl = result.appUrl || 'https://anti-doomscroll-app.vercel.app/';
    
    appUrlInput.value = appUrl;
    renderSitesList(blockedSites);
  } catch (error) {
    console.error('Error loading settings:', error);
    showNotification('Error loading settings', 'error');
  }
}

// Render the sites list
function renderSitesList(sites) {
  sitesList.innerHTML = '';
  
  Object.entries(sites).forEach(([domain, config]) => {
    const siteElement = createSiteElement(domain, config);
    sitesList.appendChild(siteElement);
  });
}

// Create a site configuration element
function createSiteElement(domain, config) {
  const div = document.createElement('div');
  div.className = 'site-config';
  div.innerHTML = `
    <div class="site-info">
      <div class="site-icon" style="background: ${getSiteColor(domain)}">
        ${config.icon || '🌐'}
      </div>
      <div>
        <div class="site-name">${domain}</div>
        <div style="font-size: 12px; color: #666;">
          ${config.enabled ? 'Blocked' : 'Allowed'}
        </div>
      </div>
    </div>
    <div class="site-controls">
      <div class="toggle ${config.enabled ? 'active' : ''}" data-domain="${domain}">
        <div class="toggle-slider"></div>
      </div>
      <input type="number" class="time-input" data-domain="${domain}" data-type="daily" 
             value="${config.dailyLimit}" min="0" max="1440" placeholder="Daily">
      <input type="number" class="time-input" data-domain="${domain}" data-type="weekly" 
             value="${config.weeklyLimit}" min="0" max="10080" placeholder="Weekly">
    </div>
  `;
  
  return div;
}

// Get site color based on domain
function getSiteColor(domain) {
  const colors = {
    'instagram.com': '#E4405F',
    'tiktok.com': '#000000',
    'twitter.com': '#1DA1F2',
    'x.com': '#1DA1F2',
    'youtube.com': '#FF0000',
    'facebook.com': '#1877F2',
    'reddit.com': '#FF4500'
  };
  return colors[domain] || '#667eea';
}

// Set up event listeners
function setupEventListeners() {
  // Toggle switches
  sitesList.addEventListener('click', (e) => {
    if (e.target.closest('.toggle')) {
      const toggle = e.target.closest('.toggle');
      const domain = toggle.dataset.domain;
      toggle.classList.toggle('active');
      
      // Update the status text
      const statusText = toggle.closest('.site-config').querySelector('.site-info div:last-child');
      statusText.textContent = toggle.classList.contains('active') ? 'Blocked' : 'Allowed';
    }
  });
  
  // Time input changes
  sitesList.addEventListener('input', (e) => {
    if (e.target.classList.contains('time-input')) {
      // Validate input
      const value = parseInt(e.target.value);
      const max = e.target.dataset.type === 'daily' ? 1440 : 10080;
      
      if (value > max) {
        e.target.value = max;
        showNotification(`Maximum ${e.target.dataset.type} limit is ${max} minutes`, 'warning');
      }
    }
  });
  
  // Save button
  saveBtn.addEventListener('click', saveSettings);
  
  // Reset button
  resetBtn.addEventListener('click', resetSettings);
  
  // Export button
  exportBtn.addEventListener('click', exportSettings);
}

// Save settings to storage
async function saveSettings() {
  try {
    const blockedSites = {};
    const siteElements = sitesList.querySelectorAll('.site-config');
    
    siteElements.forEach(element => {
      const domain = element.querySelector('.toggle').dataset.domain;
      const toggle = element.querySelector('.toggle');
      const dailyInput = element.querySelector('[data-type="daily"]');
      const weeklyInput = element.querySelector('[data-type="weekly"]');
      
      blockedSites[domain] = {
        enabled: toggle.classList.contains('active'),
        dailyLimit: parseInt(dailyInput.value) || 0,
        weeklyLimit: parseInt(weeklyInput.value) || 0,
        icon: DEFAULT_SITES[domain]?.icon || '🌐'
      };
    });
    
    const appUrl = appUrlInput.value.trim() || 'https://anti-doomscroll-app.vercel.app/';
    
    await chrome.storage.sync.set({
      blockedSites: blockedSites,
      appUrl: appUrl
    });
    
    showNotification('Settings saved successfully!', 'success');
    
    // Notify background script to update rules
    chrome.runtime.sendMessage({ action: 'updateRules' });
    
  } catch (error) {
    console.error('Error saving settings:', error);
    showNotification('Error saving settings', 'error');
  }
}

// Reset settings to defaults
async function resetSettings() {
  if (confirm('Are you sure you want to reset all settings to defaults?')) {
    try {
      await chrome.storage.sync.set({
        blockedSites: DEFAULT_SITES,
        appUrl: 'https://anti-doomscroll-app.vercel.app/'
      });
      
      await loadSettings();
      showNotification('Settings reset to defaults', 'success');
      
    } catch (error) {
      console.error('Error resetting settings:', error);
      showNotification('Error resetting settings', 'error');
    }
  }
}

// Export settings
async function exportSettings() {
  try {
    const result = await chrome.storage.sync.get(['blockedSites', 'appUrl']);
    const dataStr = JSON.stringify(result, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'anti-doomscroll-settings.json';
    link.click();
    
    URL.revokeObjectURL(url);
    showNotification('Settings exported successfully!', 'success');
    
  } catch (error) {
    console.error('Error exporting settings:', error);
    showNotification('Error exporting settings', 'error');
  }
}

// Load usage statistics
async function loadUsageStats() {
  try {
    const result = await chrome.storage.local.get();
    const usageData = {};
    
    // Extract usage data for all domains
    Object.keys(result).forEach(key => {
      if (key.startsWith('usage_')) {
        const domain = key.replace('usage_', '');
        usageData[domain] = result[key];
      }
    });
    
    renderUsageStats(usageData);
    
  } catch (error) {
    console.error('Error loading usage stats:', error);
  }
}

// Render usage statistics
function renderUsageStats(usageData) {
  const today = new Date().toDateString();
  const weekStart = new Date();
  weekStart.setDate(weekStart.getDate() - weekStart.getDay());
  
  let totalToday = 0;
  let totalWeek = 0;
  let blockedSites = 0;
  
  Object.entries(usageData).forEach(([domain, data]) => {
    const todayUsage = data.daily[today] || 0;
    const weekUsage = Object.entries(data.daily)
      .filter(([date]) => new Date(date) >= weekStart)
      .reduce((sum, [, time]) => sum + time, 0);
    
    totalToday += todayUsage;
    totalWeek += weekUsage;
    
    if (todayUsage > 0) blockedSites++;
  });
  
  statsContainer.innerHTML = `
    <div class="stat-card">
      <div class="stat-number">${Math.round(totalToday)}</div>
      <div class="stat-label">Minutes Today</div>
    </div>
    <div class="stat-card">
      <div class="stat-number">${Math.round(totalWeek)}</div>
      <div class="stat-label">Minutes This Week</div>
    </div>
    <div class="stat-card">
      <div class="stat-number">${blockedSites}</div>
      <div class="stat-label">Sites Used Today</div>
    </div>
    <div class="stat-card">
      <div class="stat-number">${Object.keys(usageData).length}</div>
      <div class="stat-label">Total Tracked Sites</div>
    </div>
  `;
}

// Show notification
function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 20px;
    border-radius: 6px;
    color: white;
    font-weight: 600;
    z-index: 1000;
    transition: all 0.3s ease;
    background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : type === 'warning' ? '#ffc107' : '#17a2b8'};
  `;
  notification.textContent = message;
  
  document.body.appendChild(notification);
  
  // Remove after 3 seconds
  setTimeout(() => {
    notification.style.opacity = '0';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 3000);
}

// Listen for storage changes
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local') {
    loadUsageStats();
  }
});
