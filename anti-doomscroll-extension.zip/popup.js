// Popup JavaScript for Anti-Doomscroll Chrome Extension

document.addEventListener('DOMContentLoaded', async () => {
    const loading = document.getElementById('loading');
    const content = document.getElementById('content');
    const error = document.getElementById('error');
    const errorMessage = document.getElementById('errorMessage');
    
    try {
        // Load popup data
        await loadPopupData();
        
        // Set up event listeners
        setupEventListeners();
        
        // Show content
        loading.style.display = 'none';
        content.style.display = 'block';
        
    } catch (err) {
        console.error('Error loading popup:', err);
        loading.style.display = 'none';
        error.style.display = 'block';
        errorMessage.textContent = err.message;
    }
});

// Load data for popup
async function loadPopupData() {
    // Get current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const currentUrl = tab?.url || '';
    const currentDomain = new URL(currentUrl).hostname;
    
    // Get settings
    const settings = await chrome.storage.sync.get(['blockedSites', 'appUrl']);
    const blockedSites = settings.blockedSites || {};
    const appUrl = settings.appUrl || 'https://anti-doomscroll-app.vercel.app/';
    
    // Get usage statistics
    const usageStats = await getUsageStats();
    
    // Update UI
    updateStats(usageStats);
    updateCurrentSiteInfo(currentDomain, blockedSites);
    updateAppUrl(appUrl);
}

// Get usage statistics
async function getUsageStats() {
    const result = await chrome.storage.local.get();
    const usageData = {};
    
    // Extract usage data for all domains
    Object.keys(result).forEach(key => {
        if (key.startsWith('usage_')) {
            const domain = key.replace('usage_', '');
            usageData[domain] = result[key];
        }
    });
    
    const today = new Date().toDateString();
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    
    let totalToday = 0;
    let blockedSites = 0;
    
    Object.entries(usageData).forEach(([domain, data]) => {
        const todayUsage = data.daily[today] || 0;
        totalToday += todayUsage;
        if (todayUsage > 0) blockedSites++;
    });
    
    return {
        todayMinutes: Math.round(totalToday),
        blockedSites: blockedSites,
        totalSites: Object.keys(usageData).length
    };
}

// Update statistics display
function updateStats(stats) {
    document.getElementById('todayMinutes').textContent = stats.todayMinutes;
    document.getElementById('blockedSites').textContent = stats.blockedSites;
}

// Update current site information
function updateCurrentSiteInfo(domain, blockedSites) {
    const currentSiteInfo = document.getElementById('currentSiteInfo');
    const siteIcon = document.getElementById('siteIcon');
    const siteName = document.getElementById('siteName');
    const siteStatus = document.getElementById('siteStatus');
    
    // Check if current site is monitored
    let isMonitored = false;
    let siteConfig = null;
    
    for (const [blockedDomain, config] of Object.entries(blockedSites)) {
        if (domain === blockedDomain || domain.endsWith('.' + blockedDomain)) {
            isMonitored = true;
            siteConfig = config;
            break;
        }
    }
    
    if (isMonitored) {
        currentSiteInfo.style.display = 'block';
        siteIcon.textContent = siteConfig?.icon || '🌐';
        siteName.textContent = domain;
        
        if (siteConfig?.enabled) {
            siteStatus.textContent = 'Monitored & Blocked';
            siteStatus.style.color = '#ff6b6b';
        } else {
            siteStatus.textContent = 'Monitored Only';
            siteStatus.style.color = '#4ecdc4';
        }
    } else {
        currentSiteInfo.style.display = 'none';
    }
}

// Update app URL
function updateAppUrl(appUrl) {
    const openAppBtn = document.getElementById('openApp');
    openAppBtn.href = appUrl;
}

// Set up event listeners
function setupEventListeners() {
    // Open settings
    document.getElementById('openSettings').addEventListener('click', (e) => {
        e.preventDefault();
        chrome.runtime.openOptionsPage();
    });
    
    // Quick actions
    document.getElementById('pauseAll').addEventListener('click', pauseAllSites);
    document.getElementById('resumeAll').addEventListener('click', resumeAllSites);
    document.getElementById('viewStats').addEventListener('click', openStatsPage);
    document.getElementById('exportData').addEventListener('click', exportData);
}

// Pause all site blocking
async function pauseAllSites() {
    try {
        const result = await chrome.storage.sync.get(['blockedSites']);
        const blockedSites = result.blockedSites || {};
        
        // Disable all sites
        Object.keys(blockedSites).forEach(domain => {
            blockedSites[domain].enabled = false;
        });
        
        await chrome.storage.sync.set({ blockedSites });
        
        showNotification('All sites paused', 'success');
        setTimeout(() => location.reload(), 1000);
        
    } catch (error) {
        console.error('Error pausing sites:', error);
        showNotification('Error pausing sites', 'error');
    }
}

// Resume all site blocking
async function resumeAllSites() {
    try {
        const result = await chrome.storage.sync.get(['blockedSites']);
        const blockedSites = result.blockedSites || {};
        
        // Enable all sites
        Object.keys(blockedSites).forEach(domain => {
            blockedSites[domain].enabled = true;
        });
        
        await chrome.storage.sync.set({ blockedSites });
        
        showNotification('All sites resumed', 'success');
        setTimeout(() => location.reload(), 1000);
        
    } catch (error) {
        console.error('Error resuming sites:', error);
        showNotification('Error resuming sites', 'error');
    }
}

// Open stats page
function openStatsPage() {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html') });
}

// Export data
async function exportData() {
    try {
        const settings = await chrome.storage.sync.get();
        const usageData = await chrome.storage.local.get();
        
        const exportData = {
            settings: settings,
            usageData: usageData,
            exportDate: new Date().toISOString()
        };
        
        const dataStr = JSON.stringify(exportData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `anti-doomscroll-data-${new Date().toISOString().split('T')[0]}.json`;
        link.click();
        
        URL.revokeObjectURL(url);
        showNotification('Data exported successfully!', 'success');
        
    } catch (error) {
        console.error('Error exporting data:', error);
        showNotification('Error exporting data', 'error');
    }
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 10px;
        right: 10px;
        padding: 10px 15px;
        border-radius: 4px;
        color: white;
        font-size: 12px;
        font-weight: 600;
        z-index: 1000;
        background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#17a2b8'};
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 3000);
}
